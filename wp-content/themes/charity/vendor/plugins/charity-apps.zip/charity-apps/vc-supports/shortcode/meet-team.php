<?php 
function charity_vc_meet_team( $atts, $content = null ) {
	 get_template_part("content/our", "team");
}
