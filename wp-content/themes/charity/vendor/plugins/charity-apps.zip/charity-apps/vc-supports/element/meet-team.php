<?php 

return array(
      "name"              => __("Meet our team", "charity"),
      "base"              => "meet_team",
      "class"             => "",
      "icon"              => "icon-charity",
      "description"       => "Place meet our team",
      "category"          => __('Charity Shortcodes', "charity"),
      "params"            => array()
   );
